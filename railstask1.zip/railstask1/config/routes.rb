Rails.application.routes.draw do
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"

  get "/articles", to: "article#index"

  get "/articles/:id", to: "article#findid"

  post "/articles", to: "article#add"

  put "/articles/:id", to: "article#update"

  delete "/articles/:id", to: "article#delete"

  get "/articles/category/:category", to: "article#findcategory"

  post "articles/filterdate",  to: "article#daterange"
  post "articles/partialsearch", to: "article#searchauthor"

  get "/articles/author/:author", to: "article#findauthor"

  get "/users", to: "user#index"
  post "/users", to: "user#add"
  delete "/users/:id", to: "user#delete"
  post "/users/check", to: "user#check"
  put "users/passwordupdate", to: "user#update"
end
