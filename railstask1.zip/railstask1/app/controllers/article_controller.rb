class ArticleController < ApplicationController
    skip_before_action :verify_authenticity_token
    def index
        articles=Article.all
        render json: articles
    end

    def findid
        article=Article.find(params[:id])
        render json: article
    end

    def add
        a= Article.create(author: params[:author], category: params[:category], da: params[:da], content: params[:content])
        render json: a 
    end 

    def update
        a=Article.find(params[:id])
        a.update(author: params[:author], category: params[:category], da: params[:da], content: params[:content])
        render json: a
    end

    def delete
        a=Article.find(params[:id])
        a.destroy
        render json: a
    end

    def findcategory
        articles=Article.where(category: params[:category])
        render json: articles
    end

    def daterange
        articles=Article.where(:da => params[:startdate]..params[:enddate])
        render json:articles 
    end

    def searchauthor
        search=params[:name]
        articles=Article.where("author LIKE ?", "%#{search}%")
        render json: articles
    end

    def findauthor
        articles=Article.where(author: params[:author])
        render json: articles
    end


end
