class UserController < ApplicationController
    skip_before_action :verify_authenticity_token
    def index
        u=User.all
        render json:u
    end
    def add
        a= User.create(name: params[:name], phone: params[:phone], email: params[:email], password: params[:password])
        render json: a 
    end
    
    def check
        user=User.find_by_email(params[:email])
        if user.password == params[:password]
            render html: "match found"
        else
            render html: "match not found"
        end
    end


    def update
        user=User.find_by_email(params[:email])
        if user.password == params[:oldpassword]
            user.update(password: params[:newpassword])
            render html: "Password Updated"
        else
            render html: "Wrong Old Password"
        end
        
    end

    def delete
        u=User.find(params[:id])
        u.destroy
        render json: u
    end
end
