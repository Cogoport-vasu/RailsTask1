class Article < ApplicationRecord
end
